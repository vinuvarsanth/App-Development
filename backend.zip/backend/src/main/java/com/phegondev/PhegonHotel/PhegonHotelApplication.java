package com.phegondev.PhegonHotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhegonHotelApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhegonHotelApplication.class, args);
    }

}
