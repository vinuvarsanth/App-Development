package com.phegondev.PhegonHotel.exception;

public class OurException extends RuntimeException {

    public OurException(String message) {
        super(message);
    }
}
